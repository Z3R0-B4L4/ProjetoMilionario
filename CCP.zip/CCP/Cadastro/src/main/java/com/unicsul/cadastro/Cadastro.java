/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.unicsul.cadastro;
import java.util.Scanner;
/**
 *
 * @author autologon
 */
public class Cadastro {

    public static void main(String[] args) {
        int n1,n2,maior;
        Scanner scan = new Scanner(System.in);
        System.out.print("Digite um numero: ");
        n1 = scan.nextInt();
        System.out.print("Digite outro numero: ");
        n2 = scan.nextInt();
        
        if(n1 > n2){
            maior = n1;
            System.out.print("O maior valor é: " + maior);
        }else if(n2 > n1){
            maior = n2;
            System.out.print("Omaior valor é: " + maior);
        }else{
            System.out.print("Os valores digitados são iguais");
        }
    }
}
